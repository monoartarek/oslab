# Operating Systems Lab Manual
### Experiments 1–11: Scheduling, Synchronization & Deadlock

Every experiment below follows the same workflow in Linux. Learn this once, reuse it for all 11:

```bash
# 1. Go to (or create) your working folder
mkdir -p ~/os_lab
cd ~/os_lab

# 2. Create the file and open it in vim
vim exp1_fcfs.c

# --- inside vim ---
# press  i              -> enters INSERT mode, now you can type/paste the code
# (type or paste the program)
# press  Esc             -> leaves insert mode
# type   :wq             -> writes (saves) the file and quits vim
# (or  :wq!  to force save,  :q!  to quit WITHOUT saving)

# 3. Compile with gcc
gcc exp1_fcfs.c -o fcfs

# 4. Run it
./fcfs
```

For any program that uses **threads/semaphores** (Experiments 5–9) you must link the pthread library:

```bash
gcc exp5_producer_consumer.c -o pc -lpthread
./pc
```

If you ever see "permission denied" when running `./fcfs`, do:
```bash
chmod +x fcfs
./fcfs
```

All programs below take **dynamic input** — the user is asked to enter the number of processes/resources/threads etc. at runtime, so you can test as many scenarios as you like without touching the code.

---

## EXPERIMENT 1 — First-Come, First-Served (FCFS) Scheduling

### Theory
FCFS is the simplest CPU scheduling algorithm. Processes are executed strictly in the order they arrive in the ready queue — like a queue at a ticket counter. It is **non-preemptive**: once the CPU is given to a process, it runs to completion.

Key terms:
- **Arrival Time (AT):** when the process enters the ready queue.
- **Burst Time (BT):** CPU time the process needs.
- **Completion Time (CT):** when the process finishes execution.
- **Turnaround Time (TAT)** = CT − AT
- **Waiting Time (WT)** = TAT − BT

### Algorithm
1. Sort processes by arrival time.
2. Execute processes in that order; a process starts as soon as the CPU is free **and** it has arrived.
3. Compute CT, TAT, WT for each process, then find averages.

### Advantages / Disadvantages
- ✅ Simple to implement, no starvation.
- ❌ **Convoy effect**: a long process ahead makes all shorter processes behind it wait a long time.

### Linux Commands
```bash
cd ~/os_lab
vim exp1_fcfs.c        # paste code, Esc, :wq
gcc exp1_fcfs.c -o fcfs
./fcfs
```

### Sample Run
```
Enter number of processes: 3
Enter Arrival Time and Burst Time for P1: 0 5
Enter Arrival Time and Burst Time for P2: 1 3
Enter Arrival Time and Burst Time for P3: 2 8
```

### Full Code
See `exp1_fcfs.c` (attached).

---

## EXPERIMENT 2 — Shortest-Job-First (SJF) Scheduling

### Theory
SJF picks, from among the processes that have **already arrived**, the one with the **smallest burst time** to run next. This experiment implements the **non-preemptive** version (once started, a process runs to completion even if a shorter job arrives later).

### Algorithm
1. At every decision point, look at all arrived-but-not-finished processes.
2. Choose the one with the minimum burst time.
3. Run it fully, update the clock, repeat until all processes finish.

### Advantages / Disadvantages
- ✅ Minimizes average waiting time among non-preemptive algorithms.
- ❌ **Starvation** possible: long processes may wait indefinitely if short jobs keep arriving. Requires knowing burst time in advance (usually estimated).

### Linux Commands
```bash
vim exp2_sjf.c
gcc exp2_sjf.c -o sjf
./sjf
```

### Full Code
See `exp2_sjf.c` (attached).

---

## EXPERIMENT 3 — Priority Scheduling

### Theory
Each process is assigned a **priority number**; the CPU is always given to the highest-priority process among those that have arrived (in this program, **lower number = higher priority**, a common convention). This implementation is **non-preemptive**.

### Algorithm
1. Among arrived, unfinished processes, pick the one with the smallest priority value.
2. Run it to completion.
3. Repeat.

### Advantages / Disadvantages
- ✅ Important/urgent jobs (e.g. system processes) can be run first.
- ❌ **Starvation** of low-priority processes. Fixed by **aging** — gradually increasing the priority of processes that wait too long.

### Linux Commands
```bash
vim exp3_priority.c
gcc exp3_priority.c -o priority
./priority
```

### Full Code
See `exp3_priority.c` (attached).

---

## EXPERIMENT 4 — Round Robin (RR) Scheduling

### Theory
Designed for time-sharing systems. Each process gets the CPU for a fixed **time quantum**; if it doesn't finish, it goes to the back of the ready queue and waits its turn again. This is **preemptive**.

### Algorithm
1. Maintain a ready queue (FIFO).
2. Pop the front process, run it for `min(remaining burst time, time quantum)`.
3. If it still has remaining burst time, push it to the back of the queue (after any processes that arrived during its slice).
4. Repeat until all processes finish.

### Key Design Point
Choice of quantum matters:
- Too large → behaves like FCFS.
- Too small → excessive context-switching overhead.

### Linux Commands
```bash
vim exp4_rr.c
gcc exp4_rr.c -o rr
./rr
```

### Full Code
See `exp4_rr.c` (attached).

---

## EXPERIMENT 5 — Producer/Consumer Problem

### Theory
Classic synchronization problem. A **producer** thread generates data and places it in a shared buffer; a **consumer** thread removes data from the buffer. Problems arise if both access the buffer at the same time (race condition), or if the producer tries to add to a full buffer / consumer tries to remove from an empty buffer.

Solved using:
- **`empty`** semaphore — counts empty slots (starts = buffer size).
- **`full`** semaphore — counts filled slots (starts = 0).
- **mutex** — ensures mutual exclusion while updating the buffer indices.

### Algorithm (Producer)
```
wait(empty)      // wait for a free slot
lock(mutex)
  add item to buffer
unlock(mutex)
signal(full)     // announce a new full slot
```
### Algorithm (Consumer)
```
wait(full)       // wait for an item
lock(mutex)
  remove item from buffer
unlock(mutex)
signal(empty)    // announce a new empty slot
```

### Linux Commands (needs pthread)
```bash
vim exp5_producer_consumer.c
gcc exp5_producer_consumer.c -o pc -lpthread
./pc
```

### Full Code
See `exp5_producer_consumer.c` (attached).

---

## EXPERIMENT 6 — Bounded-Buffer Problem

### Theory
An extension of Producer/Consumer to a **fixed-size (bounded) circular buffer** with **multiple** producers and multiple consumers competing for buffer slots. It demonstrates that the same `empty`/`full`/`mutex` scheme scales to many threads safely.

### Algorithm
Same as Experiment 5, but:
- Multiple producer threads share the buffer — mutex protects the shared `in` index.
- Multiple consumer threads share the buffer — mutex protects the shared `out` index.
- A shared counter ensures exactly the right total number of consume operations happen.

### Linux Commands
```bash
vim exp6_bounded_buffer.c
gcc exp6_bounded_buffer.c -o bb -lpthread
./bb
```

### Full Code
See `exp6_bounded_buffer.c` (attached).

---

## EXPERIMENT 7 — Readers and Writers Problem

### Theory
Multiple **reader** threads may read shared data simultaneously (reading doesn't change data, so it's safe). But a **writer** needs **exclusive** access — no other reader or writer may touch the data while writing. This program implements the classic **readers-priority** solution.

### Algorithm
- A counter `read_count` tracks the number of active readers.
- The **first** reader to arrive locks the `rw_mutex` (blocking writers); the **last** reader to leave unlocks it.
- Writers simply wait on `rw_mutex` directly.

```
Reader:
  lock(mutex); read_count++;
  if (read_count == 1) wait(rw_mutex)   // first reader blocks writers
  unlock(mutex)
  ... read data ...
  lock(mutex); read_count--;
  if (read_count == 0) signal(rw_mutex) // last reader unblocks writers
  unlock(mutex)

Writer:
  wait(rw_mutex)
  ... write data ...
  signal(rw_mutex)
```

### Linux Commands
```bash
vim exp7_readers_writers.c
gcc exp7_readers_writers.c -o rw -lpthread
./rw
```

### Full Code
See `exp7_readers_writers.c` (attached).

---

## EXPERIMENT 8 — Dining Philosophers Problem

### Theory
`N` philosophers sit around a circular table with one fork between each pair (N forks total). To eat, a philosopher needs **both** the fork to their left and right. If everyone picks up their left fork at once, no one can pick up a right fork — **deadlock** (circular wait).

### Deadlock-Avoidance Trick Used Here
Make **one** philosopher (the last one, index N−1) pick up the **right** fork first instead of the left. This breaks the circular-wait condition, so deadlock cannot occur.

### Algorithm
```
for each philosopher i:
  think()
  if i is the last philosopher:
     pick up right fork, then left fork
  else:
     pick up left fork, then right fork
  eat()
  put down both forks
```

### Linux Commands
```bash
vim exp8_dining_philosophers.c
gcc exp8_dining_philosophers.c -o dp -lpthread
./dp
```

### Full Code
See `exp8_dining_philosophers.c` (attached).

---

## EXPERIMENT 9 — The Sleeping Barber Problem

### Theory
A barbershop has one barber, one barber chair, and `N` waiting-room chairs.
- If no customers, the barber **sleeps**.
- A customer who arrives while the barber sleeps wakes him up and gets a haircut.
- A customer who arrives while the barber is busy sits in a free waiting chair, if any.
- A customer who arrives when all waiting chairs are full **leaves**.

### Algorithm
Uses two semaphores:
- `customers` — signals the barber that a customer is waiting (barber sleeps by waiting on this).
- `barber_ready` — signals a customer that the barber is free.
- A `mutex`-protected counter `waiting` tracks free waiting-room chairs.

```
Barber:
  wait(customers)     // sleep until someone arrives
  signal(barber_ready)
  cut_hair()

Customer:
  lock(mutex)
  if waiting < chairs:
      waiting++
      unlock(mutex)
      signal(customers)      // wake barber
      wait(barber_ready)      // wait for turn
      get_haircut()
  else:
      unlock(mutex)
      leave()
```

### Linux Commands
```bash
vim exp9_sleeping_barber.c
gcc exp9_sleeping_barber.c -o barber -lpthread
./barber
```

### Full Code
See `exp9_sleeping_barber.c` (attached).

---

## EXPERIMENT 10 — Resource-Allocation Graph Algorithm (Deadlock Detection)

### Theory
A **Resource-Allocation Graph (RAG)** models processes (P) and resource types (R) as nodes:
- An edge **R → P** means the resource is *allocated to* the process.
- An edge **P → R** means the process is *requesting* the resource.

If the graph (with single-instance resources) contains a **cycle**, the system is deadlocked. For resources with **multiple instances**, a cycle is only a *necessary* condition, not sufficient — so we use the standard **detection algorithm** (similar to the Banker's safety algorithm) based on Allocation, Request, and Available matrices.

### Algorithm
1. `Work = Available`; mark all processes as unfinished.
2. Find an unfinished process `i` whose `Request[i] <= Work`. If found:
   - `Work += Allocation[i]`
   - mark `i` as finished, repeat.
3. If no such process is found and some processes remain unfinished → those processes are **deadlocked**.
4. If all processes finish → **no deadlock**.

### Linux Commands
```bash
vim exp10_raga.c
gcc exp10_raga.c -o raga
./raga
```

### Sample Input (no deadlock)
```
Processes: 3   Resources: 3
Allocation:
0 1 0
2 0 0
3 0 3
Request:
0 0 0
0 0 0
0 0 0
Available:
0 0 0
```

### Full Code
See `exp10_raga.c` (attached).

---

## EXPERIMENT 11 — Banker's Algorithm (Deadlock Avoidance)

### Theory
Proposed by Dijkstra, the Banker's Algorithm avoids deadlock by only granting a resource request if the resulting state is **safe** — i.e., there exists *some* order in which all processes can finish, even in the worst case (every process eventually requests its full declared maximum).

Data structures:
- **Max[i][j]** — maximum instances of resource `j` process `i` may ever need.
- **Allocation[i][j]** — instances of resource `j` currently held by process `i`.
- **Need[i][j] = Max[i][j] − Allocation[i][j]** — instances process `i` may still request.
- **Available[j]** — instances of resource `j` currently free.

### Safety Algorithm
1. `Work = Available`, `Finish[i] = false` for all `i`.
2. Find an `i` with `Finish[i] == false` and `Need[i] <= Work`.
3. If found: `Work += Allocation[i]`, `Finish[i] = true`, add `i` to the safe sequence, go to step 2.
4. If no such `i` exists:
   - If all `Finish[i] == true` → system is in a **safe state**, safe sequence found.
   - Otherwise → **unsafe state** (deadlock risk).

### Linux Commands
```bash
vim exp11_bankers.c
gcc exp11_bankers.c -o bankers
./bankers
```

### Sample Input (classic textbook example — Silberschatz)
```
Processes: 5   Resources: 3
Max:
7 5 3
3 2 2
9 0 2
2 2 2
4 3 3
Allocation:
0 1 0
2 0 0
3 0 2
2 1 1
0 0 2
Available:
3 3 2
```
Expected output: **Safe state**, one valid safe sequence is `P1 P3 P4 P0 P2`.

### Full Code
See `exp11_bankers.c` (attached).

---

## Quick Reference: All Compile Commands

| # | File | Compile Command |
|---|------|------------------|
| 1 | exp1_fcfs.c | `gcc exp1_fcfs.c -o fcfs` |
| 2 | exp2_sjf.c | `gcc exp2_sjf.c -o sjf` |
| 3 | exp3_priority.c | `gcc exp3_priority.c -o priority` |
| 4 | exp4_rr.c | `gcc exp4_rr.c -o rr` |
| 5 | exp5_producer_consumer.c | `gcc exp5_producer_consumer.c -o pc -lpthread` |
| 6 | exp6_bounded_buffer.c | `gcc exp6_bounded_buffer.c -o bb -lpthread` |
| 7 | exp7_readers_writers.c | `gcc exp7_readers_writers.c -o rw -lpthread` |
| 8 | exp8_dining_philosophers.c | `gcc exp8_dining_philosophers.c -o dp -lpthread` |
| 9 | exp9_sleeping_barber.c | `gcc exp9_sleeping_barber.c -o barber -lpthread` |
| 10 | exp10_raga.c | `gcc exp10_raga.c -o raga` |
| 11 | exp11_bankers.c | `gcc exp11_bankers.c -o bankers` |

**Rule of thumb:** any program using `pthread.h` or `semaphore.h` needs `-lpthread` at the end of the compile command. Plain scheduling programs (1–4, 10, 11) don't need it.

### Useful vim reminders
| Action | Keys |
|--------|------|
| Enter insert/edit mode | `i` |
| Leave insert mode | `Esc` |
| Save and quit | `:wq` |
| Quit without saving | `:q!` |
| Save without quitting | `:w` |
| Undo | `u` (in normal mode) |
